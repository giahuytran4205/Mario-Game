#include "Random.hpp"

bool randByProbability(float rate) {
	return false;
}