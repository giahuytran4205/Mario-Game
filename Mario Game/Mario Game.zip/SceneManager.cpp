#include "SceneManager.hpp"

SceneManager* SceneManager::m_instance = nullptr;